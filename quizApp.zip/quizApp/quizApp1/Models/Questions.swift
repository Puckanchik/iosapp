import Foundation


struct Question {
    let id : Int
    var image_source: String
    var answers: [String]
    var right_answer: Int
}
