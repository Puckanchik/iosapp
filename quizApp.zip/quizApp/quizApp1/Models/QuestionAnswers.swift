
import Foundation



struct QuestionAnswer {
    let id : Int
    var image_source: String
    var answers: [String]
    var choosen: Int
    var isRight : Bool
}
